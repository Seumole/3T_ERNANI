let n = 0 

const intervalo1 = setInterval(function(){
  console.clear()
  console.log(n)
  n = n + 1
}, 1000)